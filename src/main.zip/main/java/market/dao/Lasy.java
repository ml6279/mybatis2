package market.dao;

import market.entity.Teacher;

public interface Lasy {
    //根据教师id去查教师
    public Teacher queryTeacher(int tid);
}
